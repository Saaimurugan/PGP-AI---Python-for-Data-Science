import spacy
import jinja2
import json
import cgi
from spacy import displacy
from pathlib import Path
from flask import Flask, render_template, url_for, request, make_response, jsonify
#from spacy.lang.en import English

testNameList = []
sentenceList = []
SVGList = []

app = Flask(__name__)
#nlp = spacy.load("en_core_web_sm")
nlp = spacy.load("D:/Python/Model/NewModel")

testName = u"Noun"
#stringList = [u"Saai Murugan and Chitra live in a city in which the traffic is way to heavy", u"I work and Deanta and i am a boy.", u"Deanta Global"]

#for string in stringList:
#    doc = nlp(string)
#    svg = displacy.render(doc, style="dep")
#    testNameList.append(testName)
#    sentenceList.append(string)
#    SVGList.append(svg)

@app.route('/index', methods=['POST'])
def NLPProcess():
    source = request.form['NLPData']
    stringList = source.splitlines()
    data = ""
    for string in stringList:
        doc = nlp(string)
        ent = displacy.render(doc, style="ent")
        svg = displacy.render(doc, style="dep")
        POS = "<table><tr><th>TEXT</th><th>LEMMA</th><th>POS</th><th>TAG</th><th>DEP</th><th>SHAPE</th><th>ALPHA</th><th>STOP</th></tr>"
        XML = "<root><data><text>" + string + "</text>" + "\n" 
        for token in doc:
            POS = POS + "<tr><td>" + token.text + "</td><td>" + token.lemma_ + "</td><td>" + token.pos_ + "</td><td>" + token.tag_ + "</td><td>" + token.dep_ + "</td><td>" + token.shape_ + "</td><td>" + str(token.is_alpha) + "</td><td>" + str(token.is_stop) + "</td></tr>"
            XML = XML + "\t<words pos='" + token.pos_ + "' lemma='" + token.lemma_ + "' tag='" + token.tag_ + "' dep='" + token.dep_ + "' alpha='" + str(token.is_alpha) + "' stop='" + str(token.is_stop) + "'>\n\t\t" + token.text + "\n\t</words>\n"
        POS = POS + "</table>"
        XML = XML + "</data>"
        data = data + ent + "<br/>" + svg + "<br/>" + POS + "<br/>" + "<pre>" + cgi.escape(XML) + "</pre><br/><br/><hr/>"
    return data

@app.route('/')
def index():
   return render_template('index.html')

if __name__ == "__main__":
    app.run(debug=True)



