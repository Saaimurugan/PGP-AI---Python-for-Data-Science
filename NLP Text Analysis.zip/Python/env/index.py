from __future__ import unicode_literals, print_function
import plac
import random
from pathlib import Path
import spacy
from spacy.util import minibatch, compounding
import jinja2
import json
import cgi
import sys
from spacy import displacy
from pathlib import Path
from flask import Flask, render_template, url_for, request, make_response, jsonify, redirect, render_template

app = Flask(__name__)
nlp = spacy.load("en_core_web_sm")
result = ""

TAG_MAP = {"N": {"pos": "NOUN"}, "V": {"pos": "VERB"}, "J": {"pos": "ADJ"}}
TAG_MAP_ALL = {"NNP": "N", "VBZ": "V", "VBG": "V", "ADJ": "A"}

TRAIN_DATA = []
TRAIN_DATA_POS = []
ModelPath = "D:/Python/Model/NewModel"
testNameList = []
sentenceList = []
SVGList = []

@plac.annotations(
   model=("Model name. Defaults to blank 'en' model.", "option", "m", str),
   lang=("ISO Code of language to use", "option", "l", str),
   output_dir=("Optional output directory", "option", "o", Path),
   n_iter=("Number of training iterations", "option", "n", int),
)
def main(model="en_core_web_sm", lang="en" , output_dir=ModelPath, n_iter=100):
   """Load the model, set up the pipeline and train the entity recognizer."""

   if model is not None:
      nlp = spacy.load(model)  # load existing spaCy model
      tagger = nlp.create_pipe("tagger")
      print("Loaded model '%s'" % model)
      for tag, values in TAG_MAP.items():
         tagger.add_label(tag, values)
   else:
      nlp = spacy.blank("en")  # create blank Language class
      print("Created blank 'en' model")
      # add the tagger to the pipeline
      # nlp.create_pipe works for built-ins that are registered with spaCy
      tagger = nlp.create_pipe("tagger")
      # Add the tags. This needs to be done before you start training.
      for tag, values in TAG_MAP.items():
         tagger.add_label(tag, values)
      nlp.add_pipe(tagger)


   optimizer = nlp.begin_training()
   for i in range(n_iter):
      random.shuffle(TRAIN_DATA_POS)
      losses = {}
      # batch up the examples using spaCy's minibatch
      batches = minibatch(TRAIN_DATA_POS, size=compounding(4.0, 32.0, 1.001))
      for batch in batches:
         texts, annotations = zip(*batch)
         print (annotations)
         nlp.update(texts, annotations, sgd=optimizer, losses=losses)
      print("Losses", losses)

   # create the built-in pipeline components and add them to the pipeline
   # nlp.create_pipe works for built-ins that are registered with spaCy
   if "ner" not in nlp.pipe_names:
      ner = nlp.create_pipe("ner")
      nlp.add_pipe(ner, last=True)
   # otherwise, get it so we can add labels
   else:
      ner = nlp.get_pipe("ner")

   # add labels
   for _, annotations in TRAIN_DATA:
      for ent in annotations.get("entities"):
         print(ent)
         ner.add_label(ent[2])

   # get names of other pipes to disable them during training
   other_pipes = [pipe for pipe in nlp.pipe_names if pipe != "ner"]
   with nlp.disable_pipes(*other_pipes):  # only train NER
      # reset and initialize the weights randomly – but only if we're
      # training a new model
      if model is None:
         nlp.begin_training()
      for itn in range(n_iter):
         random.shuffle(TRAIN_DATA)
         losses = {}
         # batch up the examples using spaCy's minibatch
         batches = minibatch(TRAIN_DATA, size=compounding(4.0, 32.0, 1.001))
         for batch in batches:
               texts, annotations = zip(*batch)
               nlp.update(
                  texts,  # batch of texts
                  annotations,  # batch of annotations
                  drop=0.5,  # dropout - make it harder to memorise data
                  losses=losses,
               )
         print("Losses", losses)

   # test the trained model
   for text, _ in TRAIN_DATA:
      doc = nlp(text)
      T = ""
      E = ""

      for token in doc:
         T = T + token.text + "----->" + str(token.ent_type_) + "----->"  + str(token.ent_iob) + "<br/>" +  "----->"  + str(token.tag_) + "----->"  + str(token.pos_)

      for ent in doc.ents:
         E = E + ent.text + "----->" + ent.label_ + "<br/>"
      
      result = T + E
      
      #print("Entities", [(ent.text, ent.label_) for ent in doc.ents])
      #print("Tokens", [(t.text, t.ent_type_, t.ent_iob) for t in doc])

   # save model to output directory
   print(output_dir)
   if output_dir is not None:
      output_dir = Path(output_dir)
      if not output_dir.exists():
         output_dir.mkdir()
      nlp.to_disk(output_dir)
      print("Saved model to", output_dir)

      # test the saved model
      print("Loading from", output_dir)
      nlp2 = spacy.load(output_dir)
      for text, _ in TRAIN_DATA:
         doc = nlp2(text)
         # test the trained model
         for text, _ in TRAIN_DATA:
            doc = nlp(text)
            T = ""
            E = ""
            for token in doc:
               T = T + token.text + "----->" + str(token.ent_type_) + "----->"  + str(token.ent_iob) + "<br/>"

            for ent in doc.ents:
               E = E + ent.text + "----->" + ent.label_ + "<br/>"
            
            result = T + E

         #print("Entities", [(ent.text, ent.label_) for ent in doc.ents])
         #print("Tokens", [(t.text, t.ent_type_, t.ent_iob) for t in doc])
   return result

@app.route('/train', methods=['GET'])
def train():
   if request.method == 'POST':
   # do stuff when the form is submitted
   # redirect to end the POST handling
   # the redirect can be to the same route or somewhere else
      return redirect(url_for('train'))
   return render_template('train.html')

@app.route('/train', methods=['POST'])
def NERTraining():
   #try:
   data = request.form['TrainingData']
   paramData = data.split("|")
   arg_tri = (int(paramData[1]), int(paramData[2]), str(paramData[3]))
   arg_arr = [arg_tri]
   print (arg_arr)
   dic = {"entities": arg_arr}
   print (dic)
   concateArr = (paramData[0], dic)
   print (concateArr)
   TRAIN_DATA.append((concateArr))

   doc = nlp(paramData[0])
   arg_arr_pos = []
   contentSpaceSplit = []
   contentSpaceSplit = paramData[0].split(" ")
   i = 0
   print (paramData[0])
   for token in doc:
      arg1 = contentSpaceSplit[i].strip().lower()
      arg2 = paramData[0][int(paramData[1]):int(paramData[2])
      ].strip().lower()
      if arg1 == arg2:
         arg_arr_pos.append("N")
      else:
         arg_arr_pos.append(TAG_MAP_ALL[token.tag_])
      print (arg_arr_pos)
      dic_pos = {"tags": arg_arr_pos}
      print (dic_pos)
      i=i+1
   concateArr_pos = (paramData[0], dic_pos)
   print (concateArr_pos)
   #TRAIN_DATA = [("I like green eggs", {"tags": ["N", "V", "J", "N"]})]
   TRAIN_DATA_POS.append((concateArr_pos))
   #TRAIN_DATA.append(("Google rebrands its business apps", {"entities": [(0, 6, "ORG")]}))
   #TRAIN_DATA.append((u"Google rebrands its business apps", {"entities": [(0, 6, "ORG")]}))
   result = plac.call(main)
   data = result
   #except:
      #data = "Oops!" + sys.exc_info()[0] + "occured."
   return data
   #return data


@app.route('/index', methods=['POST'])
def NLPProcess():
   #nlp = spacy.load("en_core_web_sm")
   #nlp = spacy.load(ModelPath)
   source = request.form['NLPData']
   selectedModel = request.form['Model']
   nlp = spacy.load(selectedModel)
   stringList = source.splitlines()
   data = ""
   for string in stringList:
      doc = nlp(string)
      ent = displacy.render(doc, style="ent")
      svg = displacy.render(doc, style="dep")
      POS = "<table class='table table-bordered table-fixed'><thead><tr><th class='col-xs-3'>TEXT</th><th class='col-xs-3'>SENT</th><th class='col-xs-3'>ORTH</th><th class='col-xs-3'>VOCAB</th><th class='col-xs-3'>INDEX</th><th class='col-xs-3'>Named entity type</th><th class='col-xs-3'>IOB code</th><th class='col-xs-3'>Ent_id_</th><th class='col-xs-3'>Norm</th><th class='col-xs-3'>LEMMA</th><th class='col-xs-3'>POS</th><th class='col-xs-3'>TAG</th><th class='col-xs-3'>HEAD</th><th class='col-xs-3'>DEP</th><th class='col-xs-3'>DEP ID</th><th class='col-xs-3'>SHAPE</th><th class='col-xs-3'>ALPHA</th><th class='col-xs-3'>STOP</th><th class='col-xs-3'>PROB</th><th class='col-xs-3'>Cluster</th><th class='col-xs-3'>Sentiment</th></tr></thead><tbody>"
      #XML = "<root><data><text>" + string + "</text>" + "\n" 
      for token in doc:
         POS = POS + "<tr><td class='col-xs-3'>" + token.text + "</td><td class='col-xs-3'>" + str(token.sent) + "</td><td class='col-xs-3'>" + token.orth_ + "</td><td class='col-xs-3'>" + str(token.vocab) + "</td><td class='col-xs-3'>" + str(token.i) + "</td><td class='col-xs-3'>" + token.ent_type_ + "</td><td class='col-xs-3'>" + token.ent_iob_ + "</td><td class='col-xs-3'>" + token.ent_id_ + "</td><td class='col-xs-3'>" + token.norm_ + "</td><td class='col-xs-3'>" + token.lemma_ + "</td><td class='col-xs-3'>" + token.pos_ + "</td><td class='col-xs-3'>" + token.tag_ + "</td><td class='col-xs-3'>" + str(token.head) + "</td><td class='col-xs-3'>" + token.dep_ + "</td><td class='col-xs-3'>" + str(token.dep) + "</td><td class='col-xs-3'>" + token.shape_ + "</td><td class='col-xs-3'>" + str(token.is_alpha) + "</td><td class='col-xs-3'>" + str(token.is_stop) + "</td><td class='col-xs-3'>" + str(token.prob) + "</td><td class='col-xs-3'>" + str(token.cluster) + "</td><td class='col-xs-3'>" + str(token.sentiment) + "</td></tr>"
         #XML = XML + "\t<words pos='" + token.pos_ + "' lemma='" + token.lemma_ + "' tag='" + token.tag_ + "' dep='" + token.dep_ + "' alpha='" + str(token.is_alpha) + "' stop='" + str(token.is_stop) + "'>\n\t\t" + token.text + "\n\t</words>\n"
      POS = POS + "</tbody></table>"
      #XML = XML + "</data>"
      data = data + "<h2>" + selectedModel + "</h2>" + ent + "<br/>" + svg + "<br/>" + POS + "<br/>" + "<br/><br/><hr/>"
      #data = data + "<h2>" + selectedModel + "</h2>" + ent + "<br/>" + svg + "<br/>" + POS + "<br/>" + "<pre>" + cgi.escape(XML) + "</pre><br/><br/><hr/>"
   return data

@app.route('/')
def index():
   return render_template('index.html')

if __name__ == "__main__":
   #plac.call(main)
   app.run(debug=True)



