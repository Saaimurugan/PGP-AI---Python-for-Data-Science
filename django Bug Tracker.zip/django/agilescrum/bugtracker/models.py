from django.db import models
from datetime import datetime

# Create your models here.
class bugtracker(models.Model):
    bugtracker_title = models.CharField(max_length = 200)
    product_id = models.IntegerField(default = 0)
    bugtracker_description = models.TextField()
    bugtracker_status = models.BooleanField(default = True)
    bugtracker_type = models.CharField(max_length = 10)
    bugtracker_requested_user = models.CharField(max_length = 200)
    bugtracker_reason = models.TextField()
    bugtracker_priority = models.BooleanField()
    bugtracker_created_date = models.DateTimeField(default = datetime.now, blank = True)
    objects = models.Manager()
    def __str__(self):
        return self.bugtracker_title +  " User:"  + self.bugtracker_requested_user