from django.shortcuts import render, HttpResponseRedirect
from django.http import HttpResponse
from product.models import product

from .models import bugtracker

# Create your views here.
def bugtrackerlist(request):
    if request.session.session_key == None:
        return HttpResponseRedirect('login') # or http response
    bugtrackers = bugtracker.objects.all()
    productItem = product.objects.all()
    #productItem = product.objects.get(id=productid)

    context = {
        'title': 'Bug Tracker',
        'productItem': productItem,
        'bugtracker': bugtrackers
    }
    return render(request, 'bugtracker/bugtracker.html', context)

def bugtrackerdetails(request, id):
    if request.session.session_key == None:
        return HttpResponseRedirect('login') # or http response

    bugtrackers = bugtracker.objects.get(id=id) 
    context = {
        'bugtrackerdetails': bugtrackers
    }
    return render(request, 'bugtracker/details.html', context)