from django.apps import AppConfig


class BugtrackerConfig(AppConfig):
    name = 'bugtracker'
