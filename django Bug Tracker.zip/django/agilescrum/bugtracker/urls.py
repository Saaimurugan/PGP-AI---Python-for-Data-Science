from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^$', views.bugtrackerlist, name='bugtracker'),
    url(r'details/(?P<id>\d+)/$', views.bugtrackerdetails, name='bugtrackerdetails'),
]