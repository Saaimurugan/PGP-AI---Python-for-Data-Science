from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^$', views.sprintbackloglist, name='sprintbacklog'),
    url(r'details/(?P<id>\d+)/$', views.sprintbacklogdetails, name='sprintbacklogdetails'),
]