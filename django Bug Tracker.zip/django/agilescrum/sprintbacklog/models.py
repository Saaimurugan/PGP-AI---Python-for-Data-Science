from django.db import models
from datetime import datetime

# Create your models here.
class sprintbacklog(models.Model):
    sprintbacklog_title = models.CharField(max_length = 200)
    product_id = models.IntegerField(default = 0)
    sprintbacklog_description = models.TextField()
    sprintbacklog_status = models.BooleanField(default = True)
    sprintbacklog_type = models.CharField(max_length = 10)
    sprintbacklog_requested_user = models.CharField(max_length = 200)
    sprintbacklog_reason = models.TextField()
    sprintbacklog_priority = models.BooleanField()
    sprintbacklog_created_date = models.DateTimeField(default = datetime.now, blank = True)
    objects = models.Manager()
    def __str__(self):
        return self.sprintbacklog_title +  " User:"  + self.sprintbacklog_requested_user