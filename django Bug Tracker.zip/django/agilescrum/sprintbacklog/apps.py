from django.apps import AppConfig


class SprintbacklogConfig(AppConfig):
    name = 'sprintbacklog'
