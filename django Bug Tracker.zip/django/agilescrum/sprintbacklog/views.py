from django.shortcuts import render, HttpResponseRedirect
from django.http import HttpResponse
from product.models import product

from .models import sprintbacklog

# Create your views here.
def sprintbackloglist(request):
    if request.session.session_key == None:
        return HttpResponseRedirect('loginpage') # or http response
    sprintbacklogs = sprintbacklog.objects.all()
    productItem = product.objects.all()
    #productItem = product.objects.get(id=productid)

    context = {
        'title': 'Sprint Back Log',
        'productItem': productItem,
        'sprintbacklog': sprintbacklogs
    }
    return render(request, 'sprintbacklog/sprintbacklog.html', context)

def sprintbacklogdetails(request, id):
    if request.session.session_key == None:
        return HttpResponseRedirect('loginpage') # or http response

    sprintbacklogs = sprintbacklog.objects.get(id=id) 
    context = {
        'sprintbacklogdetails': sprintbacklogs
    }
    return render(request, 'sprintbacklog/details.html', context)