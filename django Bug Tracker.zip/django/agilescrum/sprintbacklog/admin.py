from django.contrib import admin

# Register your models here.
from .models import sprintbacklog

admin.site.register(sprintbacklog)
