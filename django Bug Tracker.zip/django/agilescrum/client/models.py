from django.db import models
from datetime import datetime

# Create your models here.
class client(models.Model):
    client_name = models.CharField(max_length = 200)
    client_description = models.TextField()
    client_active = models.BooleanField(default = True)
    client_zone = models.CharField(max_length = 10)
    client_description = models.TextField()
    client_created_date = models.DateTimeField(default = datetime.now, blank = True)
    objects = models.Manager()
    def __str__(self):
        return self.client_name

