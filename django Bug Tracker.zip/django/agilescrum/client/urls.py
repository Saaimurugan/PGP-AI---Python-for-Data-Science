from django.conf.urls import url
from . import views

print("Client URL")
urlpatterns = [
    url(r'^$', views.index, name='index'),
    url(r'details/(?P<id>\d+)/$', views.details, name='details'),
    #url(r'search/$', views.search, name="search")
]
    #url(r'details/(?P<id>\d+)/$', views.productbacklogdetails, name='productbacklogdetails'),
