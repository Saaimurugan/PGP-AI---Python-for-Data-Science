from django.shortcuts import render, redirect, HttpResponseRedirect
from django.http import HttpResponse

from .models import client

# Create your views here.
def index(request):
    if request.session.session_key == None:
        return HttpResponseRedirect('login') # or http response
        
    clientList = client.objects.all()
    context = {
        'title': 'Clients',
        'clientList':clientList
    }
    return render(request, 'client/index.html', context)

def details(request, id):
    if request.session.session_key == None:
        return HttpResponseRedirect('login') # or http response

    clientItem = client.objects.get(id=id) 
    context = {
        'clientItem': clientItem
    }
    return render(request, 'client/details.html', context)