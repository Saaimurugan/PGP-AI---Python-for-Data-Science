from django.contrib import admin

# Register your models here.
from .models import client

admin.site.register(client)
