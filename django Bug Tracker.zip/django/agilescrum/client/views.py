from django.shortcuts import render, redirect, HttpResponseRedirect
from django.http import HttpResponse
from django.db.models import Q

from .models import client

# Create your views here.
def index(request):
    print('index')
    if request.session.session_key == None:
        return HttpResponseRedirect('loginpage') # or http response
        
    clientList = client.objects.all()
    context = {
        'title': 'Clients',
        'clientList':clientList
    }
    return render(request, 'client/index.html', context)

def details(request, id):
    print('details')
    if request.session.session_key == None:
        return HttpResponseRedirect('loginpage') # or http response

    clientItem = client.objects.get(id=id) 
    context = {
        'clientItem': clientItem
    }
    return render(request, 'client/details.html', context)

def search(request):
    print('search')
    print('------------------------------------------------------')
    query = request.GET.get('q')
    print (query)
    print('------------------------------------------------------')
    results = client.objects.filter(Q(client_name__icontains=query) | Q(client_description__icontains=query))
    print (results)
    print('------------------------------------------------------')
    context = {
        'title': 'Clients Search Result',
        'clientList':results
    }
    return render(request, 'client/index.html', context)