from django.apps import AppConfig


class ProductbacklogConfig(AppConfig):
    name = 'productbacklog'
