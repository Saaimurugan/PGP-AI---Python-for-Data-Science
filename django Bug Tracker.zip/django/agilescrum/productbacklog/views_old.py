from django.shortcuts import render, HttpResponseRedirect
from django.http import HttpResponse
from product.models import product

from .models import productbacklog

# Create your views here.
def productbackloglist(request):
    if request.session.session_key == None:
        return HttpResponseRedirect('login') # or http response
    productbacklogs = productbacklog.objects.all()
    productItem = product.objects.all()
    #productItem = product.objects.get(id=productid)

    context = {
        'title': 'Product Back Log',
        'productItem': productItem,
        'productbacklog': productbacklogs
    }
    return render(request, 'productbacklog/productbacklog.html', context)

def productbacklogdetails(request, id):
    if request.session.session_key == None:
        return HttpResponseRedirect('login') # or http response

    productbacklogs = productbacklog.objects.get(id=id) 
    context = {
        'productbacklogdetails': productbacklogs
    }
    return render(request, 'productbacklog/details.html', context)