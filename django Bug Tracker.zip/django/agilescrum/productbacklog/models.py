from django.db import models
from datetime import datetime

# Create your models here.
class productbacklog(models.Model):
    productbacklog_title = models.CharField(max_length = 200)
    product_id = models.IntegerField(default = 0)
    productbacklog_description = models.TextField()
    productbacklog_status = models.BooleanField(default = True)
    productbacklog_type = models.CharField(max_length = 10)
    productbacklog_requested_user = models.CharField(max_length = 200)
    productbacklog_reason = models.TextField()
    productbacklog_priority = models.BooleanField()
    productbacklog_created_date = models.DateTimeField(default = datetime.now, blank = True)
    objects = models.Manager()
    def __str__(self):
        return self.productbacklog_title +  " User:"  + self.productbacklog_requested_user