from django.shortcuts import render, HttpResponseRedirect
from django.http import HttpResponse
from product.models import product
from django.db.models import Q
from .models import productbacklog

# Create your views here.
def productbackloglist(request):
    if request.session.session_key == None:
        return HttpResponseRedirect('loginpage') # or http response
    productbacklogs = productbacklog.objects.all()
    
    #productItem = product.objects.get(id=productid)

    context = {
        'title': 'Product Back Log',
        #'productItem': productItem,
        'productbacklog': productbacklogs
    }
    return render(request, 'productbacklog/productbacklog.html', context)

def productbacklogdetails(request, id):
    if request.session.session_key == None:
        return HttpResponseRedirect('loginpage') # or http response

    productbacklogs = productbacklog.objects.get(id=id) 
    context = {
        'productbacklogdetails': productbacklogs
    }
    return render(request, 'productbacklog/details.html', context)

def search(request):
    print('Productbacklog Search')
    print('------------------------------------------------------')
    query = request.GET.get('q')
    print (query)
    print('------------------------------------------------------')
    results = productbacklog.objects.filter(Q(productbacklog_title__icontains=query) | Q(productbacklog_description__icontains=query))
    print (results)
    print('------------------------------------------------------')
    context = {
        'title': 'Product backlog Search Result',
        'productbacklog': results
    }
    return render(request, 'productbacklog/productbacklog.html', context)