from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^$', views.productbackloglist, name='productbacklog'),
    url(r'details/(?P<id>\d+)/$', views.productbacklogdetails, name='productbacklogdetails'),
]
