from django.shortcuts import render, redirect, HttpResponseRedirect
from django.http import HttpResponse

from django.contrib.auth import authenticate, login
from django.contrib import messages, redirects

# Create your views here.
def loginpage(request):
    message = {
        'message': 'First'
    }
    return render(request, 'login/login.html', message)

def logincheck(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            if user.is_active:
                login(request, user)
                return redirect('index')
            else:
                messages.error(request,'username or password not correct')
                return redirect('login')
    return render(request, 'todo/login.html')


