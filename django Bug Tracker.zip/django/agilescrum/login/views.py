from django.shortcuts import render, redirect, HttpResponseRedirect
from django.http import HttpResponse

from django.contrib.auth import authenticate, login
from django.contrib import messages, redirects

# Create your views here.
def loginpage(request):
    return render(request, 'login/login.html')

def logincheck(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        print(user)
        if user is not None:
            if user.is_active:
                login(request, user)
                return redirect('index')
            else:
                message = {
                    'message': 'User is inactive!!!'
                }       
                #return redirect('logincheck', message)
                return render(request, 'login/login.html', message)
        else:
            message = {
                'message': 'Invalid username or password!!!'
            }       
            #return redirect('logincheck', message)
            return render(request, 'login/login.html', message)
    #return render(request, 'login/login.html')


