from django.db import models
from datetime import datetime

# Create your models here.
class product(models.Model):    
    product_name = models.CharField(max_length = 200)
    product_description = models.TextField()
    product_active = models.BooleanField(default = True)
    product_type = models.CharField(max_length = 10)
    product_created_date = models.DateTimeField(default = datetime.now, blank = True)
    objects = models.Manager()
    def __str__(self):
        return self.product_name