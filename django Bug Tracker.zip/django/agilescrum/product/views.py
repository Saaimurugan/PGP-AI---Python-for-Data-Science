from django.shortcuts import render, HttpResponseRedirect
from django.http import HttpResponse

# Create your views here.
def product(request):
    if request.session.session_key == None:
        #return HttpResponseRedirect('login') # or http response
        return render(request, 'login/login.html')

    #return HttpResponse('Worked')
    return render(request, 'product/product.html')